package com.example.springbootErpNext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootErpNextApplicationTests {

	@Test
	void contextLoads() {
	}

}
