package com.example.springbootErpNext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootErpNextApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootErpNextApplication.class, args);
	}

}
